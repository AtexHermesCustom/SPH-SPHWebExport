/*
 * File:    FormattedWebExportServlet.java
 *
 * Copyright (c) 2012,  Atex Media Command GmbH
 *                      Kurhessenstrasse 13
 *                      64546 Moerfelden-Walldorf
 *                      Germany
 *
 * Audit:
 * v01.00  06-jun-2012  st  Initial version.
 * v00.00  18-apr-2012  st  Created.
 */

package de.atex.h11.custom.sph.export.webapp;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.color.ColorSpace;
import java.awt.image.BufferedImage;
import java.awt.image.ColorConvertOp;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.util.Map;
import java.util.Date;
import java.util.Locale;
import java.util.TreeSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.text.NumberFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import javax.imageio.ImageIO;
import javax.imageio.IIOImage;
import javax.imageio.ImageWriter;
import javax.imageio.ImageWriteParam;
import javax.imageio.stream.ImageOutputStream;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Document;
import org.w3c.dom.ProcessingInstruction;
import org.apache.log4j.Logger;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.codec.binary.Base64;
import com.unisys.media.cr.adapter.ncm.model.data.datasource.NCMDataSource;
import com.unisys.media.cr.adapter.ncm.model.data.values.NCMObjectValueClient;
import com.unisys.media.cr.adapter.ncm.common.data.pk.NCMObjectPK;
import com.unisys.media.cr.adapter.ncm.common.data.values.NCMObjectBuildProperties;
import com.unisys.media.cr.adapter.ncm.common.data.types.NCMObjectNodeType;

/**
 *
 * @author tstuehler
 */
public class FormattedWebExportServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        NCMDataSource ds = null;

        String strUser = request.getParameter("user");
        String strPasswd = request.getParameter("password");
        String strSessionId = request.getParameter("sessionid");
        String strObjId = request.getParameter("id");
        String strNodeType = request.getParameter("nodetype");
        if (strObjId == null) {
            strObjId = request.getParameter("ncm-obj-id");
            if (strObjId != null && strNodeType == null)
                strNodeType = "ncm-object";
        }

        if (strUser == null && strPasswd == null) {
            // TODO: check if we got a http auth header !!!
            strUser = "BATCH";
            strPasswd = "BATCH";
        }

        logger.debug(request.getParameterMap().toString());  // For debugging only!

        if (strNodeType == null) {
            response.sendError(response.SC_BAD_REQUEST, "Node type required.");
            return;
        }

        if (!strNodeType.equals("ncm-object")) {
            response.sendError(response.SC_BAD_REQUEST, "Provided object is of wrong type.");
            return;
        }

        if ((strUser == null || strPasswd == null) && strSessionId == null) {
            response.sendError(response.SC_UNAUTHORIZED, "User credentials required!");
            return;
        }
        
        try {
            props = getProperties();
            String strTextConvert = props.getProperty("text.convert"); // converter format
            
            // Prepare the URL.
            String strUrl = props.getProperty("destinationURL");
            if (strUrl == null) {
                throw new RuntimeException("Required property destinationURL not found.");
            }
            URL url = new URL(strUrl);

            if (strSessionId != null)
                ds = (NCMDataSource) DataSource.newInstance(strSessionId);
            else
                ds = (NCMDataSource) DataSource.newInstance(strUser, strPasswd);

            String[] sa = strObjId.split(":");
            NCMObjectPK objPK = null;
            if (props.getProperty("ignoreLayoutId", "false").equalsIgnoreCase("true")) {
                objPK = new NCMObjectPK(Integer.parseInt(sa[0]));
            } else {
                objPK = new NCMObjectPK(Integer.parseInt(sa[0]),
                        Integer.parseInt(sa[1]), NCMObjectPK.LAST_VERSION, 
                        NCMObjectPK.ACTIVE);                
            }

            NCMObjectBuildProperties objProps = new NCMObjectBuildProperties();
            NCMObjectValueClient currentObj = (NCMObjectValueClient) ds.getNode(objPK, objProps);
            objProps.setIncludeObjContent(true);
            if (currentObj.getType() != NCMObjectNodeType.OBJ_STORY_PACKAGE) {
                int spId = currentObj.getSpId();
                if (spId > 0) {
                    objPK = new NCMObjectPK(spId);
                } else {
                    response.sendError(response.SC_BAD_REQUEST, "Object not part of a package.");
                    return;
                }
            }
            
            StoryPackage sp = new StoryPackage(ds);
            Document doc = docBuilder.newDocument();
            DOMSource source = new DOMSource(sp.getDocument(objPK, strTextConvert));
            DOMResult result = new DOMResult(doc);
            Transformer t = transformerFactory.newTransformer(new StreamSource(
                getClass().getClassLoader().getResourceAsStream(
                "de/atex/h11/custom/sph/export/webapp/ncm-web.xsl")));
            Iterator iter = props.stringPropertyNames().iterator();
            while (iter.hasNext()) {
                String strProp = (String) iter.next();
                if (strProp.startsWith("xslt.param.")) {
                    t.setParameter(strProp.replaceFirst("xslt.param.", ""), 
                            props.getProperty(strProp) == null ? "" : props.getProperty(strProp));
                }
            }
            t.transform(source, result);

            NodeList nl3 = doc.getDocumentElement().getChildNodes();
            for (int k = 0; k < nl3.getLength(); k++) {
                Node n = nl3.item(k);
                Document storyDoc = docBuilder.newDocument();
                storyDoc.appendChild(storyDoc.importNode(n, true));
            
                // retrieve Newsroom tags and finalize text formatting
                handleTags(storyDoc);

                // include image files
                float jpegQuality = Float.parseFloat(props.getProperty("jpegQuality", "0.5"));
                
                // check if this is a STORY or an IMAGE xml file
                boolean isImageXML = ((Boolean) xp.evaluate("/nitf/head/docdata/definition/@type = 'IMAGE'", storyDoc, XPathConstants.BOOLEAN)).booleanValue();
                
                // 20120607 jpm: process photo nodes of both STORY and IMAGE xml files
                //NodeList nl = (NodeList) xp.evaluate("/nitf[head/docdata/definition/@type='STORY']/body/photo", storyDoc, XPathConstants.NODESET);
                NodeList nl = (NodeList) xp.evaluate("/nitf/body/photo", storyDoc, XPathConstants.NODESET);
                for (int i = 0; i < nl.getLength(); i++) {
                    int rotationAngle = getRotationAngle(nl.item(i));
                    Dimension dimension = getDimension(nl.item(i));
                    Rectangle cropRect = getCropRect(nl.item(i));
                    String strHighResPath = getHighResImagePath(nl.item(i));
                    String strMedResPath = getMedResImagePath(nl.item(i));
                    String strLowResPath = getLowResImagePath(nl.item(i));

                    // get the destination file name
                    String strThumbnailTarget = null;
                    String strLowResTarget = null;
                    NodeList nl2 = nl.item(i).getChildNodes();
                    for (int j = 0; j < nl2.getLength(); j++) {
                        if (nl2.item(j).getNodeType() == Node.ELEMENT_NODE 
                                && nl2.item(j).getLocalName().equals("image_thumbnail"))
                            strThumbnailTarget = nl2.item(j).getTextContent();
                        else if (nl2.item(j).getNodeType() == Node.ELEMENT_NODE 
                                && nl2.item(j).getLocalName().equals("image_low"))
                            strLowResTarget = nl2.item(j).getTextContent();
                    }

                    // dump the files
                    /*write(url, strLowResTarget, crop(new File(strMedResPath), cropRect, dimension, rotationAngle));
                    logger.debug("Wrote " + strLowResTarget + " to " + url + ".");
                    write(url, strThumbnailTarget, crop(new File(strLowResPath), cropRect, dimension, rotationAngle));
                    logger.debug("Wrote " + strThumbnailTarget + " to " + url + ".");*/
                    File highResFile = new File(strHighResPath);
                    if (props.getProperty("useOriginalAsLowres", "false").equalsIgnoreCase("true")) {
                        String strSuffix = null;
                        int pos = highResFile.getName().lastIndexOf('.');
                        if (pos > 0) strSuffix = highResFile.getName().substring(pos);
                        if (!strSuffix.equalsIgnoreCase(".jpg")) {
                            pos = strLowResTarget.lastIndexOf('.');
                            if (pos > 0) {
                                strLowResTarget = strLowResTarget.substring(0, pos) + strSuffix.toLowerCase();
                                Element e = (Element) xp.evaluate("./image_low", nl.item(i), XPathConstants.NODE);
                                if (e != null) e.setTextContent(strLowResTarget);
                            }
                        }
                        if (isImageXML) {
                            if (cropRect != null && props.getProperty("cropLowres", "true").equalsIgnoreCase("true") && strSuffix.equalsIgnoreCase(".jpg")) {
                                byte[] imageBytes = crop(highResFile, cropRect, dimension, rotationAngle);
                                write(url, strLowResTarget, imageBytes);
                            } else {
                                write(url, strLowResTarget, new FileInputStream(highResFile));
                            }
                            logger.debug("Wrote " + strLowResTarget + " to " + url + ".");
                        }
                    } else {
                        if (isImageXML) {
                            File medResFile = new File(strMedResPath);
                            if (cropRect != null && props.getProperty("cropLowres", "true").equalsIgnoreCase("true")) {
                                byte[] imageBytes = crop(medResFile, cropRect, dimension, rotationAngle);
                                write(url, strLowResTarget, imageBytes);
                            } else {
                                write(url, strLowResTarget, new FileInputStream(medResFile));
                            }
                            logger.debug("Wrote " + strLowResTarget + " to " + url + ".");
                        }
                    }
                    if (props.getProperty("omitThumbnail", "false").equalsIgnoreCase("false")) {
                        if (isImageXML) {
                            File lowResFile = new File(strLowResPath);
                            if (cropRect != null && props.getProperty("cropThumbnail", "true").equalsIgnoreCase("true")) {
                                byte[] imageBytes = crop(lowResFile, cropRect, dimension, rotationAngle);
                                write(url, strThumbnailTarget, imageBytes);
                            } else {
                                write(url, strThumbnailTarget, new FileInputStream(lowResFile));
                            }
                            logger.debug("Wrote " + strThumbnailTarget + " to " + url + ".");
                        }
                    } else {
                        Element e = (Element) xp.evaluate("./image_thumbnail", nl.item(i), XPathConstants.NODE);
                        if (e != null) e.setTextContent("");
                    }
                }

                String strFileName = getFileName(storyDoc);

                // Get rid of remaining processing instructions.
                nl = (NodeList) xp.evaluate("//processing-instruction()",
                                            storyDoc, XPathConstants.NODESET);
                for (int i = 0; i < nl.getLength(); i++) {
                    String strTarget = ((ProcessingInstruction) nl.item(i)).getTarget();
                    nl.item(i).getParentNode().removeChild(nl.item(i));
                }

                // dump the XML document
                write(url, strFileName, storyDoc);
                logger.debug("Wrote " + strFileName + " to " + url + ".");
            }
            
            out.println("<html>");
            out.println("<head>");
            out.println("<title>FormattedWebExportServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>" + "Object " + strObjId
                    + " has been exported successfully." + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } catch (Exception e) {
            logger.error("", e);
            response.sendError(response.SC_CONFLICT, e.toString());
        } finally {            
            out.close();
            if (ds != null) ds.logout();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    public String getServletInfo() {
        return "Formatted Web Export";
    }// </editor-fold>
    
    
    public void init () throws ServletException {
        try {
            docBuilder = docBuilderFactory.newDocumentBuilder();
            transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty(OutputKeys.STANDALONE, "yes");
            transformer.setOutputProperty(OutputKeys.CDATA_SECTION_ELEMENTS, 
                "caption copyright person title country kick content h1 h2");
            transformer.setOutputProperty("{http://xml.apache.org/xsl}indent-amount", "4");
            
            String strStyleFile = props.getProperty("styleFile");
            if (strStyleFile != null) {
                tcHM = StyleReader.getTagCategories(strStyleFile);
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }
    
    private Properties getProperties () throws IOException {
        Properties props = new Properties();

        String strJBossHomeDir = System.getProperty("jboss.server.home.dir");
        String strPropsFile = strJBossHomeDir + File.separator + "conf"
                                + File.separator + "SPHWebExport.properties";
        File propsFile = new File(strPropsFile);
        try {
            props.load(new FileInputStream(propsFile));
        } catch (FileNotFoundException fnf) {
            logger.warn("", fnf);
        }

        return props;
    }

    
    private Dimension getDimension (Node contNode) throws ParseException {
        Dimension dimension = null;

        NodeList nl = contNode.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            if (nl.item(i).getNodeType() == Node.PROCESSING_INSTRUCTION_NODE) {
                // remove the processing instruction
                String strTarget = ((ProcessingInstruction) nl.item(i)).getTarget();
                if (strTarget.equals("dimension")) {
                    String strData = ((ProcessingInstruction) nl.item(i)).getData();
                    String[] s = strData.split(" ");
                    if (s.length == 2) {
                        int width = df.parse(s[0]).intValue();
                        int height = df.parse(s[1]).intValue();
                        dimension = new Dimension(width, height);
                    } else {
                        throw new RuntimeException("Invalid dimension data found in processing instruction.");
                    }
                    Node parent = nl.item(i).getParentNode();
                    parent.removeChild(nl.item(i));
                }
            }
        }

        return dimension;
    }


    private Rectangle getCropRect (Node contNode) {
        Rectangle cropRect = null;

        NodeList nl = contNode.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            if (nl.item(i).getNodeType() == Node.PROCESSING_INSTRUCTION_NODE) {
                // remove the processing instruction
                String strTarget = ((ProcessingInstruction) nl.item(i)).getTarget();
                if (strTarget.equals("crop-rect")) {
                    String strData = ((ProcessingInstruction) nl.item(i)).getData();
                    String[] s = strData.split(" ");
                    if (s.length == 4) {
                        int bottom = Integer.parseInt(s[0]);
                        int left = Integer.parseInt(s[1]);
                        int top = Integer.parseInt(s[2]);
                        int right = Integer.parseInt(s[3]);
                        cropRect = new Rectangle(left, top, right - left, bottom - top);
                    } else {
                        throw new RuntimeException("Invalid crop data found in processing instruction.");
                    }
                    Node parent = nl.item(i).getParentNode();
                    parent.removeChild(nl.item(i));
                }
            }
        }

        return cropRect;
    }

    
    private int getRotationAngle (Node contNode) throws ParseException {
        int rotationAngle = 0;

        NodeList nl = contNode.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            if (nl.item(i).getNodeType() == Node.PROCESSING_INSTRUCTION_NODE) {
                // remove the processing instruction
                String strTarget = ((ProcessingInstruction) nl.item(i)).getTarget();
                if (strTarget.equals("rotate")) {
                    String strData = ((ProcessingInstruction) nl.item(i)).getData();
                    rotationAngle = df.parse(strData).intValue();
                    Node parent = nl.item(i).getParentNode();
                    parent.removeChild(nl.item(i));
                }
            }
        }

        return rotationAngle;
    }


    private String getHighResImagePath (Node contNode) throws ParseException {
        String strImagePath = null;

        NodeList nl = contNode.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            if (nl.item(i).getNodeType() == Node.PROCESSING_INSTRUCTION_NODE) {
                // remove the processing instruction
                String strTarget = ((ProcessingInstruction) nl.item(i)).getTarget();
                if (strTarget.equals("highres-imagepath")) {
                    strImagePath = ((ProcessingInstruction) nl.item(i)).getData();
                    Node parent = nl.item(i).getParentNode();
                    parent.removeChild(nl.item(i));
                }
            }
        }

        return strImagePath;
    }


    private String getMedResImagePath (Node contNode) throws ParseException {
        String strImagePath = null;

        NodeList nl = contNode.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            if (nl.item(i).getNodeType() == Node.PROCESSING_INSTRUCTION_NODE) {
                // remove the processing instruction
                String strTarget = ((ProcessingInstruction) nl.item(i)).getTarget();
                if (strTarget.equals("medres-imagepath")) {
                    strImagePath = ((ProcessingInstruction) nl.item(i)).getData();
                    Node parent = nl.item(i).getParentNode();
                    parent.removeChild(nl.item(i));
                }
            }
        }

        return strImagePath;
    }


    private String getLowResImagePath (Node contNode) throws ParseException {
        String strImagePath = null;

        NodeList nl = contNode.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            if (nl.item(i).getNodeType() == Node.PROCESSING_INSTRUCTION_NODE) {
                // remove the processing instruction
                String strTarget = ((ProcessingInstruction) nl.item(i)).getTarget();
                if (strTarget.equals("lowres-imagepath")) {
                    strImagePath = ((ProcessingInstruction) nl.item(i)).getData();
                    Node parent = nl.item(i).getParentNode();
                    parent.removeChild(nl.item(i));
                }
            }
        }

        return strImagePath;
    }
    
    
    private String getFileName (Node node) 
            throws ParseException, XPathExpressionException {
        String strFileName = null;

        NodeList nl = (NodeList) xp.evaluate("//processing-instruction()",
                                            node, XPathConstants.NODESET);
        for (int i = 0; i < nl.getLength(); i++) {
            if (nl.item(i).getNodeType() == Node.PROCESSING_INSTRUCTION_NODE) {
                // remove the processing instruction
                String strTarget = ((ProcessingInstruction) nl.item(i)).getTarget();
                if (strTarget.equals("file-name")) {
                    strFileName = ((ProcessingInstruction) nl.item(i)).getData();
                    Node parent = nl.item(i).getParentNode();
                    parent.removeChild(nl.item(i));
                }
            }
        }

        return strFileName;
    }


    private byte[] crop (File file, Rectangle cropRect, Dimension dimension, 
            int rotationAngle) throws IOException {
        byte[] imageBytes = null;

        File tempFile = File.createTempFile("web", ".jpg");
        try {
            cropImage(file, tempFile, cropRect, dimension, false);
            FileInputStream in = new FileInputStream(tempFile);
            imageBytes = new byte[(int) tempFile.length()];
            int bytesRead = 0;
            do {
                bytesRead = in.read(imageBytes, bytesRead, imageBytes.length - bytesRead);
            } while (bytesRead >= 0);
            in.close();
        } finally {
            tempFile.delete();
        }
        
        return imageBytes;
    }

    
    private void cropImage (File srcFile, File dstFile, Rectangle cropRect,
                              Dimension dimension, boolean bConvertToRGB)
            throws IOException {
        BufferedImage srcImage = ImageIO.read(srcFile); // read the source file

        // Create a cropped subimage
        int w = srcImage.getWidth();
        int h = srcImage.getHeight();
        int cropX = (int) ((float) w / (float) dimension.width
                                        * (float) cropRect.x);
        int cropY = (int) ((float) h / (float) dimension.height
                                        * (float) cropRect.y);
        int cropW = (int) ((float) w / (float) dimension.width
                        * (float) (cropRect.width - cropRect.x));
        int cropH = (int) ((float) h / (float) dimension.height
                        * (float) (cropRect.height - cropRect.y));
        BufferedImage croppedImage = srcImage.getSubimage(cropX, cropY,
                                                          cropW, cropH);
        BufferedImage dstImage = croppedImage;

        // see if color space conversion is required
        ColorSpace colorSpace = srcImage.getColorModel().getColorSpace();
        boolean bNeedsConversion = false;
        switch (colorSpace.getType()) {
            case ColorSpace.TYPE_CMY:
            case ColorSpace.TYPE_CMYK:
                bNeedsConversion = true;
                break;
        }

        if (bConvertToRGB && bNeedsConversion) {
            // convert the cropped image to rgb
            ColorConvertOp op = new ColorConvertOp(
                    croppedImage.getColorModel().getColorSpace(),
                    ColorSpace.getInstance(ColorSpace.CS_sRGB), null);
            dstImage = op.createCompatibleDestImage(croppedImage, null);
            op.filter(croppedImage, dstImage);
        }

        // Find a jpeg writer
        ImageWriter writer = null;
        Iterator iter = ImageIO.getImageWritersByFormatName("jpg");
        if (iter.hasNext()) {
            writer = (ImageWriter) iter.next();
        }

        // Prepare output file
        ImageOutputStream ios = ImageIO.createImageOutputStream(dstFile);
        writer.setOutput(ios);

        // Set the compression quality
        ImageWriteParam writeParam = writer.getDefaultWriteParam();
        writeParam.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        writeParam.setCompressionQuality(
                Float.parseFloat(props.getProperty("jpegQuality", "0.5")));

        // Write the image
        writer.write(null, new IIOImage(dstImage, null, null), writeParam);

        // Cleanup
        ios.flush();
        writer.dispose();
        ios.close();
    }
    
    
    private void write (URL destURL, String destFileName, Document doc)
            throws ProtocolException, FileNotFoundException, IOException,
            UnsupportedEncodingException, TransformerException {
        HttpURLConnection http = null;
        PrintWriter out = null;
        FTPClient ftp = null;
        Map httpHeaderFields = null;
        String httpErrDescr = null;
        String httpResponse = null;
        int httpResponseCode = 0;

        if (destFileName == null) {
            destFileName = new Date().getTime() + "-"
                    + Thread.currentThread().getId() + ".xml";
        }

        if (destURL.getProtocol().equals("file")) {
            String path = destURL.getPath();
            File file = new File(path + File.separator + destFileName);
            out = new PrintWriter(file, "UTF-8");
        } else if (destURL.getProtocol().equals("ftp")) {
            ftp = getFtpConnection(destURL);
            out = new PrintWriter(new OutputStreamWriter(
                    ftp.storeFileStream(destFileName), "UTF-8"));
        } else if (destURL.getProtocol().equals("http")) {
            String encoding = props.getProperty("http.contentEncoding", defaultContentEncoding);
            String contentType = props.getProperty("http.contentType", defaultContentType);
            http = (HttpURLConnection) destURL.openConnection();
            http.setDoOutput(true);
            http.setDoInput(true);
            http.setRequestMethod("POST");
            http.setRequestProperty("Content-Type", contentType + "; charset=" + encoding);
            http.setRequestProperty("Content-Disposition", "filename=" + destFileName);
            http.setRequestProperty("Accept", contentType);
            if (destURL.getUserInfo() != null) {
                byte[] bytes = Base64.encodeBase64(destURL.getUserInfo().getBytes());
                http.setRequestProperty("Authorization", "Basic " + new String(bytes));
            }
            http.setInstanceFollowRedirects(true);
            http.connect();
            out = new PrintWriter(new OutputStreamWriter(http.getOutputStream(), encoding));
        } else {
            throw new ProtocolException("Unsupported protocol: "
                                        + destURL.getProtocol());
        }

        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(out);
        transformer.transform(source, result);
        out.close();

        if (ftp != null) ftp.disconnect();
        if (http != null) {
            httpHeaderFields = http.getHeaderFields();
            httpResponseCode = http.getResponseCode();
            if (httpResponseCode != HttpURLConnection.HTTP_OK
                    && httpResponseCode != HttpURLConnection.HTTP_CREATED
                    && httpResponseCode != HttpURLConnection.HTTP_ACCEPTED) {
                try {
                    InputStream errStream = http.getErrorStream();
                    if (errStream != null) {
                        BufferedReader err = new BufferedReader(
                            new InputStreamReader(errStream));
                        StringBuffer errSB = new StringBuffer(2000);
                        String errStr = null;
                        while ((errStr = err.readLine()) != null) {
                            errSB.append(errStr);
                        }
                        err.close();
                        httpErrDescr = errSB.toString();
                        throw new IOException("Response code: " + httpResponseCode + " - " + httpErrDescr);
                    } else {
                        throw new IOException("Response code: " + httpResponseCode);
                    }
                } catch (Exception e) {}
            } else {
                try {
                    InputStream inStream = http.getInputStream();
                    if (inStream != null) {
                        BufferedReader resp = new BufferedReader(
                            new InputStreamReader(inStream));
                        StringBuffer sb = new StringBuffer(2000);
                        String str = null;
                        while ((str = resp.readLine()) != null) {
                            sb.append(str);
                        }
                        resp.close();
                        httpResponse = sb.toString();
                    }
                } catch (Exception e) {}
            }
            http.disconnect();
        }
    }

    
    private void write (URL destURL, String destFileName, InputStream in)
            throws ProtocolException, FileNotFoundException, IOException,
            UnsupportedEncodingException {
        HttpURLConnection http = null;
        OutputStream out = null;
        FTPClient ftp = null;
        Map httpHeaderFields = null;
        String httpErrDescr = null;
        String httpResponse = null;
        int httpResponseCode = 0;

        if (destFileName == null) {
            destFileName = new Date().getTime() + "-"
                    + Thread.currentThread().getId() + ".xml";
        }

        if (destURL.getProtocol().equals("file")) {
            String path = destURL.getPath();
            File file = new File(path + File.separator + destFileName);
            out = new FileOutputStream(file);
        } else if (destURL.getProtocol().equals("ftp")) {
            ftp = getFtpConnection(destURL);
            out = ftp.storeFileStream(destFileName);
        } else if (destURL.getProtocol().equals("http")) {
            http = (HttpURLConnection) destURL.openConnection();
            http.setDoOutput(true);
            http.setDoInput(true);
            http.setRequestMethod("POST");
            http.setRequestProperty("Content-Type", "application/octet-stream");
            http.setRequestProperty("Content-Disposition", "filename=" + destFileName);
            if (destURL.getUserInfo() != null) {
                byte[] bytes = Base64.encodeBase64(destURL.getUserInfo().getBytes());
                http.setRequestProperty("Authorization", "Basic " + new String(bytes));
            }
            http.setInstanceFollowRedirects(true);
            http.connect();
            out = http.getOutputStream();
        } else {
            throw new ProtocolException("Unsupported protocol: "
                                        + destURL.getProtocol());
        }

        streamCopy(in, out);
        in.close();
        out.close();

        if (ftp != null) ftp.disconnect();
        if (http != null) {
            httpHeaderFields = http.getHeaderFields();
            httpResponseCode = http.getResponseCode();
            if (httpResponseCode != HttpURLConnection.HTTP_OK
                    && httpResponseCode != HttpURLConnection.HTTP_CREATED
                    && httpResponseCode != HttpURLConnection.HTTP_ACCEPTED) {
                try {
                    InputStream errStream = http.getErrorStream();
                    if (errStream != null) {
                        BufferedReader err = new BufferedReader(
                            new InputStreamReader(errStream));
                        StringBuffer errSB = new StringBuffer(2000);
                        String errStr = null;
                        while ((errStr = err.readLine()) != null) {
                            errSB.append(errStr);
                        }
                        err.close();
                        httpErrDescr = errSB.toString();
                        throw new IOException("Response code: " + httpResponseCode + " - " + httpErrDescr);
                    } else {
                        throw new IOException("Response code: " + httpResponseCode);
                    }
                } catch (Exception e) {}
            } else {
                try {
                    InputStream inStream = http.getInputStream();
                    if (inStream != null) {
                        BufferedReader resp = new BufferedReader(
                            new InputStreamReader(inStream));
                        StringBuffer sb = new StringBuffer(2000);
                        String str = null;
                        while ((str = resp.readLine()) != null) {
                            sb.append(str);
                        }
                        resp.close();
                        httpResponse = sb.toString();
                    }
                } catch (Exception e) {}
            }
            http.disconnect();
        }
    }

    
    private void write (URL destURL, String destFileName, byte[] bytes)
            throws ProtocolException, FileNotFoundException, IOException,
            UnsupportedEncodingException {
        write(destURL, destFileName, new ByteArrayInputStream(bytes));
    }
    
    
    private void streamCopy (InputStream in, OutputStream out)
            throws IOException {
        byte[] buf = new byte[8192];
        int bytesRead;
        do {
            bytesRead = in.read(buf);
            if (bytesRead > 0)
                out.write(buf, 0, bytesRead);
        } while (bytesRead >= 0);
    }

    
    private FTPClient getFtpConnection (URL url) throws IOException {
        String protocol = url.getProtocol();
        String host = url.getHost();
        String userInfo = url.getUserInfo();
        String path = url.getPath();

        String[] credentials = userInfo.split(":");

        FTPClient ftp = new FTPClient();
        ftp.connect(host);
        ftp.login(credentials[0], credentials[1]);
        int reply = ftp.getReplyCode();
        if (reply == FTPReply.NOT_LOGGED_IN) {
            try { ftp.disconnect(); ftp = null; } catch (Exception e) {}
            throw new IOException("Login failed on FTP host " + host + ".");
        }
        String sysName = ftp.getSystemName();
        System.err.println("FTP system is: " + sysName);
        boolean bStatus = ftp.changeToParentDirectory();
        bStatus = ftp.changeWorkingDirectory(path);
        if (!bStatus) {
            try { ftp.logout(); ftp.disconnect(); ftp = null; } catch (Exception e) {}
            throw new IOException("Changing working directory to " + path
                                    + " failed on FTP host " + host + ".");
        }
        if (props.getProperty("ftpPassiveMode", "false").equalsIgnoreCase("true")) {
            ftp.enterLocalPassiveMode();
        }
        if (!ftp.setFileType(FTP.BINARY_FILE_TYPE)) {
            try { ftp.logout(); ftp.disconnect(); ftp = null; } catch (Exception e) {}
            throw new IOException("Failed to set binary transfer mode.");
        }

        return ftp;
    }

    
    private void handleTags (Document doc) throws XPathExpressionException {
        final String LINEBREAK = "<br/>";
        String strContent = null;
        String strHeadline = null;
        String strByline = null;
        String strEmail = null;
        String strKicker = null;
        String strTitle = null;
        String strPlace = null;
        String strSubHeadline = null;
        String strHeader = null;
        
        // content
        NodeList nl = (NodeList) xp.evaluate("//body/content", doc, XPathConstants.NODESET);
        for (int i = 0; i < nl.getLength(); i++) {
            Element e = (Element) nl.item(i);
            String strText = e.getTextContent();
            strText = removeNotes(strText);
            StringBuilder sbText = new StringBuilder(strText);
            String s = null;

            // get tagged text - note: these can be found in text or header objects
            s = getTaggedTextByCategory("BYLINE", sbText);
            if (s != null) {
                s = s.replace(LINEBREAK, " ").trim();
                // remove unnecessary text
                if (s.toUpperCase().startsWith("BY "))
                    s = s.substring(3);
                else if (s.toUpperCase().startsWith("OLEH "))
                    s = s.substring(5);     // for Malay bylines
                strByline = (strByline == null ? s : strByline + ", " + s);
            }
            s = getTaggedTextByCategory("BYLINE_TITLE", sbText);
            if (s != null) {
                s = s.replace(LINEBREAK, " ").trim();
                strTitle = (strTitle == null ? s : strTitle + ", " + s);
            }
            s = getTaggedTextByCategory("BYLINE_PLACE", sbText);
            if (s != null) {
                s = s.replace(LINEBREAK, " ").trim();
                if (s.toUpperCase().startsWith("IN "))
                    s = s.substring(3);                
                strPlace = (strPlace == null ? s : strPlace + ", " + s);
            }            
            s = getTaggedTextByCategory("EMAIL", sbText);
            if (s != null) {
                s = s.replace(LINEBREAK, " ").trim();
                strEmail = (strEmail == null ? s : strEmail + ", " + s);
            }
                       
            strText = sbText.toString();     // get remaining text
            
            // check if wie should omit some text at the beginning
            // 20120612 - no need to check
            //int startPos = findTagByCategory("TEXT", strText);
            //if (startPos > 0) strText = strText.substring(startPos);
            
            //get rid of tags
            strText = strText.replaceAll("\\[.*?\\]", "").trim();
            while (strText.startsWith(LINEBREAK)) {
                strText = strText.substring(LINEBREAK.length()).trim();
            }
            if (i > 0) {
                // we have more than a single content
                strContent += LINEBREAK + strText.trim();
                e.getParentNode().removeChild(e);   // get rid of this node
            }
            else strContent = strText.trim();
        }
        if (nl.getLength() == 0) {
            // add a content element
            //Node n = (Node) xp.evaluate("//body", doc, XPathConstants.NODE);
            Node n = (Node) xp.evaluate("/nitf[head/docdata/definition/@type='STORY']/body", doc, XPathConstants.NODE);
            if (n != null) n.appendChild(doc.createElement("content"));
        }
        
        // check if we have a headline
        nl = (NodeList) xp.evaluate("//body/h1", doc, XPathConstants.NODESET);
        if (nl.getLength() == 0) {
            // no headline, add one
            //nl = (NodeList) xp.evaluate("//body/content", doc, XPathConstants.NODESET);
            nl = (NodeList) xp.evaluate("/nitf[head/docdata/definition/@type='STORY']/body/content", doc, XPathConstants.NODESET);
            if (nl.getLength() > 0)
                nl.item(0).getParentNode().insertBefore(doc.createElement("h1"), nl.item(0));
        }
        
        // check if we have a subheadline
        nl = (NodeList) xp.evaluate("//body/h2", doc, XPathConstants.NODESET);
        if (nl.getLength() == 0) {
            // no subheadline, add one
            //nl = (NodeList) xp.evaluate("//body/content", doc, XPathConstants.NODESET);
            nl = (NodeList) xp.evaluate("/nitf[head/docdata/definition/@type='STORY']/body/content", doc, XPathConstants.NODESET);
            if (nl.getLength() > 0)
                nl.item(0).getParentNode().insertBefore(doc.createElement("h2"), nl.item(0));
        }
        
        // headline
        nl = (NodeList) xp.evaluate("//body/h1", doc, XPathConstants.NODESET);
        for (int i = 0; i < nl.getLength(); i++) {
            Element e = (Element) nl.item(0);
            String strText = e.getTextContent();
            strText = removeNotes(strText);            
            StringBuilder sbText = new StringBuilder(strText);

            if (strKicker == null) strKicker = getTaggedTextByCategory("KICKER", sbText);
            if (strSubHeadline == null) strSubHeadline = getTaggedTextByCategory("SUBHEADLINE", sbText);

            strText = sbText.toString();    // get remaining text
            
            // get rid of tags
            strText = strText.replaceAll("\\[.*?\\]", "").trim();
            e.setTextContent(strText);
            if (i > 0) {
                // we have more than a single headline
                strHeadline += " " + strText;
                e.getParentNode().removeChild(e);   // get rid of this node
            }
            else strHeadline = strText;
        }

        // summary
        nl = (NodeList) xp.evaluate("//body/summary", doc, XPathConstants.NODESET);
        for (int i = 0; i < nl.getLength(); i++) {
            Element e = (Element) nl.item(i);
            String strText = e.getTextContent();
            strText = removeNotes(strText);

            // check if wie should omit some text at the beginning
            // 20120612 - no need to check
            //int startPos = findTagByCategory("SUMMARY", strText);
            //if (startPos > 0) strText = strText.substring(startPos);

            //get rid of tags
            strText = strText.replaceAll("\\[.*?\\]", "").replaceAll("\\ +", " ").trim();
            if (strSubHeadline == null)
                strSubHeadline = strText;
            else
                strSubHeadline += " " + strText;
            
            e.getParentNode().removeChild(e);
        }

        // header
        nl = (NodeList) xp.evaluate("//body/header", doc, XPathConstants.NODESET);
        for (int i = 0; i < nl.getLength(); i++) {
            Element e = (Element) nl.item(i);        
            String strText = e.getTextContent();
            strText = removeNotes(strText);           
            StringBuilder sbText = new StringBuilder(strText);
            String s = null;

            // get tagged text - note: these can be found in text or header objects
            s = getTaggedTextByCategory("BYLINE", sbText);
            if (s != null) {
                s = s.replace(LINEBREAK, " ").trim();
                // remove unnecessary text
                if (s.toUpperCase().startsWith("BY "))
                    s = s.substring(3);
                else if (s.toUpperCase().startsWith("OLEH "))
                    s = s.substring(5);     // for Malay bylines
                strByline = (strByline == null ? s : strByline + ", " + s);
            }
            s = getTaggedTextByCategory("BYLINE_TITLE", sbText);
            if (s != null) {
                s = s.replace(LINEBREAK, " ").trim();
                strTitle = (strTitle == null ? s : strTitle + ", " + s);
            }
            s = getTaggedTextByCategory("BYLINE_PLACE", sbText);
            if (s != null) {
                s = s.replace(LINEBREAK, " ").trim();
                if (s.toUpperCase().startsWith("IN "))
                    s = s.substring(3);                
                strPlace = (strPlace == null ? s : strPlace + ", " + s);
            }            
            s = getTaggedTextByCategory("EMAIL", sbText);
            if (s != null) {
                s = s.replace(LINEBREAK, " ").trim();
                strEmail = (strEmail == null ? s : strEmail + ", " + s);
            }
                       
            strText = sbText.toString();     // get remaining text
            
            // check if wie should omit some text at the beginning
            // 20120612 - no need to check
            //int startPos = findTagByCategory("HEADER", strText);
            //if (startPos > 0) strText = strText.substring(startPos);

            //get rid of tags
            strText = strText.replaceAll("\\[.*?\\]", "").replaceAll("\\ +", " ").trim();
            if (strHeader == null)
                strHeader = strText;
            else
                strHeader += " " + strText;
            
            e.getParentNode().removeChild(e);
        }

        // photo
        NodeList nl2 = (NodeList) xp.evaluate("//body/photo", doc, XPathConstants.NODESET);
        for (int j = 0; j < nl2.getLength(); j++) {
            // caption
            nl = (NodeList) xp.evaluate("caption", nl2.item(j), XPathConstants.NODESET);
            for (int i = 0; i < nl.getLength(); i++) {
                Element e = (Element) nl.item(i);
                String strText = e.getTextContent();
                strText = removeNotes(strText);                
                StringBuilder sbText = new StringBuilder(strText);

                String strPhotoCredit = getTaggedTextByCategory("PHOTO_CREDIT", sbText);
                if (strPhotoCredit != null) {
                    strPhotoCredit = strPhotoCredit.replaceAll("\\[.*?\\]", "").trim();
                    strPhotoCredit = strPhotoCredit.replace(LINEBREAK, " ").trim();
                    Element ee = doc.createElement("copyright");
                    ee.setTextContent(strPhotoCredit.trim());
                    //e.getParentNode().insertBefore(ee, e);
                    e.getParentNode().appendChild(ee);
                }

                strText = sbText.toString();    // get remaining text

                // check if wie should omit some text at the beginning
                // 20120612 - no need to check
                //int startPos = findTagByCategory("CAPTION", strText);
                //if (startPos > 0) strText = strText.substring(startPos);

                // get rid of tags
                strText = strText.replaceAll("\\[.*?\\]", "");
                strText = strText.replace(LINEBREAK, " ").trim();
                e.setTextContent(strText.trim());
            }

            // merge multiple caption elements
            if (nl.getLength() > 1) {
                StringBuilder sbText = new StringBuilder();
                for (int i = 0; i < nl.getLength(); i++) {
                    Element e = (Element) nl.item(i);
                    sbText.append(e.getTextContent());
                    sbText.append(" ");
                }
                ((Element) nl.item(0)).setTextContent(sbText.toString().trim());
                for (int i = 1; i < nl.getLength(); i++) {
                    nl.item(i).getParentNode().removeChild(nl.item(i));
                }
            }
        }

        // set person
        if (strByline != null) {
            nl = (NodeList) xp.evaluate("//body/person", doc, XPathConstants.NODESET);
            if (nl.getLength() == 1) {
                ((Element) nl.item(0)).setTextContent(strByline.trim());
            }
        }
        
        // set email
        if (strEmail != null) {
            strEmail = strEmail.replace(LINEBREAK, " ").trim();
            nl = (NodeList) xp.evaluate("//body/series", doc, XPathConstants.NODESET);
            if (nl.getLength() == 1) {
                ((Element) nl.item(0)).setTextContent(strEmail.trim());
            }
        }
        
        // set kick
        if (strKicker != null) {
            strKicker = strKicker.trim().replaceAll("\\[.*?\\]", "");
            strKicker = strKicker.replace(LINEBREAK, " ").trim();
            nl = (NodeList) xp.evaluate("//body/kick", doc, XPathConstants.NODESET);
            if (nl.getLength() == 1) {
                ((Element) nl.item(0)).setTextContent(strKicker.trim());
            }
        }
        
        // set title
        if (strTitle != null) {
            strTitle = strTitle.replace(LINEBREAK, " ").trim();
            strTitle = strTitle.trim().replaceAll("\\[.*?\\]", "");
            nl = (NodeList) xp.evaluate("//body/title", doc, XPathConstants.NODESET);
            if (nl.getLength() == 1) {
                ((Element) nl.item(0)).setTextContent(strTitle.trim());
            }
        }
        
        // set place
        if (strPlace != null) {
            strPlace = strPlace.trim().replaceAll("\\[.*?\\]", "");
            strPlace = strPlace.replace(LINEBREAK, " ").trim();
            nl = (NodeList) xp.evaluate("//body/country", doc, XPathConstants.NODESET);
            if (nl.getLength() == 1) {
                ((Element) nl.item(0)).setTextContent(strPlace.trim());
            }
        }
        
        // set subheadline
        if (strSubHeadline != null) {
            strSubHeadline = strSubHeadline.trim().replaceAll("\\[.*?\\]", "");
            strSubHeadline = strSubHeadline.replace(LINEBREAK, " ").trim();
            nl = (NodeList) xp.evaluate("//body/h2", doc, XPathConstants.NODESET);
            if (nl.getLength() == 1) {
                nl.item(0).setTextContent(strSubHeadline.trim());
            }
        }
        
        // set content
        if (strContent != null || strHeader != null) {
            if (strContent == null)
                strContent = "";
            if (strHeader != null) 
                strContent = strContent.trim() + LINEBREAK + strHeader.trim(); // append header to content
            
            strContent = "<p>" + strContent; //beginning para
            strContent = strContent.replace(LINEBREAK, "</p><p>"); // replace line breaks with para breaks
            strContent = strContent + "</p>"; //ending para
            
            nl = (NodeList) xp.evaluate("//body/content", doc, XPathConstants.NODESET);
            if (nl.getLength() > 0) {
                ((Element) nl.item(0)).setTextContent(strContent.trim());
            }
        }
        
        // set headline
        if (strHeadline != null) {
            strHeadline = strHeadline.replace(LINEBREAK, " ").trim();
            nl = (NodeList) xp.evaluate("//body/h1", doc, XPathConstants.NODESET);
            if (nl.getLength() > 0) {
                ((Element) nl.item(0)).setTextContent(strHeadline.trim());
            }
        }
    }
    
    
    private String getTaggedTextByCategory (String strCategory, StringBuilder sbText) {
        String strTaggedText = null;
        int lastStartTagStartPos = -1;
        
        if (tcHM.containsKey(strCategory)) {
            TreeSet<TagCategory.Pair> pairSet = tcHM.get(strCategory).getTaggedText(sbText.toString(), true);
            
            // loop to look for all instances of the tag category in the text
            // if (!pairSet.isEmpty()) {
            while (!pairSet.isEmpty()) {
                TagCategory.Pair pair = pairSet.first();
                if (strTaggedText != null) {
                    if (pair.getTaggedText().getStartTagStartPos()== lastStartTagStartPos)
                        strTaggedText += pair.getTaggedText().getText(); // adjacent tagged text
                    else
                        strTaggedText += (strTaggedText + " " + pair.getTaggedText().getText()); // non-adjacent tagged text, put a space between
                }
                else
                    strTaggedText = pair.getTaggedText().getText();
                logger.debug(strCategory + "/" + pair.getTag() + ": " + strTaggedText);
                
                // delete extracted tagged text
                sbText.delete(pair.getTaggedText().getStartTagStartPos(), 
                        pair.getTaggedText().getEndTagEndPos());
                lastStartTagStartPos = pair.getTaggedText().getStartTagStartPos();  // record start pos of last tagged text found
                
                // continue to look for tagged text 
                pairSet = tcHM.get(strCategory).getTaggedText(sbText.toString(), true);
            }
        }

        return strTaggedText;
    }    
        
        
    private String getTaggedTextByCategory (String strCategory, String strText) {
        String strTaggedText = null;
        
        if (tcHM.containsKey(strCategory)) {
            TreeSet<TagCategory.Pair> pairSet = tcHM.get(strCategory).getTaggedText(strText);
            if (!pairSet.isEmpty()) {
                TagCategory.Pair pair = pairSet.first();
                strTaggedText = pair.getTaggedText().getText();
                logger.debug(strCategory + "/" + pair.getTag() + ": " + strTaggedText);
            }
        }

        return strTaggedText;
    }
        
    
    private int findTagByCategory (String strCategory, String strText) {
        int pos = -1;
        
       if (tcHM.containsKey(strCategory)) {
            TreeSet<TagCategory.Pair> pairSet = tcHM.get(strCategory).getTaggedText(strText.toString(), true);
            if (!pairSet.isEmpty()) {
                TagCategory.Pair pair = pairSet.first();
                pos = pair.getTaggedText().getStartPos();
           }
       }
        
        return pos;
    }   

    
    private String removeNotes (String strText) {
        // note: (?s) - for multiline matching
        strText = strText.replaceAll("(?s)__NOTE_CMD_BEGIN__.*?__NOTE_CMD_END__", "");
        strText = strText.replace("(?s)__NOTE_CMD_BEGIN__.*?$", ""); // last note, until end of text
        strText = strText.replaceAll("__NOTE_CMD_(BEGIN|END)__", ""); // just making sure nothing's left
        return strText;
    }

    
    private Properties props = new Properties();
    private DecimalFormat df = (DecimalFormat) NumberFormat.getNumberInstance(Locale.US);
    private HashMap<String,TagCategory> tcHM = new HashMap<String,TagCategory>();
    private DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    private TransformerFactory transformerFactory = TransformerFactory.newInstance();
    private DocumentBuilder docBuilder = null;
    private Transformer transformer = null;
    private XPathFactory xpf = XPathFactory.newInstance();
    private XPath xp = xpf.newXPath();

    private static final String defaultContentType = "text/xml";
    private static final String defaultContentEncoding = "UTF-8";
    
    private static final String loggerName = FormattedWebExportServlet.class.getName();
    private static final Logger logger = Logger.getLogger(loggerName);
}
