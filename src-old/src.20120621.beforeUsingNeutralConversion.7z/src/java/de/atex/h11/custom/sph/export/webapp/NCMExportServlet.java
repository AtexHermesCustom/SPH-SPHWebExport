/*
 * File:    NCMExportServlet.java
 *
 * Copyright (c) 2012,  Atex Media Command GmbH
 *                      Kurhessenstrasse 13
 *                      64546 Moerfelden-Walldorf
 *                      Germany
 *
 * Audit:
 * v01.00  24-apr-2012  st  Initial version.
 * v00.00  20-apr-2012  st  Created.
 */

package de.atex.h11.custom.sph.export.webapp;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.unisys.media.cr.adapter.ncm.model.data.datasource.NCMDataSource;
import com.unisys.media.cr.adapter.ncm.common.data.pk.NCMObjectPK;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

/**
 *
 * @author tstuehler
 */
public class NCMExportServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/xml;charset=UTF-8");
        //PrintWriter out = response.getWriter();
        ServletOutputStream out = response.getOutputStream();
        NCMDataSource ds = null;

        String strUser = request.getParameter("user");
        String strPasswd = request.getParameter("password");
        String strSessionId = request.getParameter("sessionid");
        String strNodeType = request.getParameter("nodetype");

        if (strUser == null && strPasswd == null) {
            // TODO: check if we got a http auth header !!!
            strUser = "BATCH";
            strPasswd = "BATCH";
        }

        if (!strNodeType.equals("sp") && !strNodeType.equals("storypackage") 
                && !strNodeType.equals("newspaper") && !strNodeType.equals("edition")) {
            throw new IllegalArgumentException("Usupported object type!");
        }

        if ((strUser == null || strPasswd == null) && strSessionId == null)
            throw new IllegalArgumentException("User credentials required!");

        try {
            Properties props = getProperties();
            String strTextConvert = props.getProperty("text.convert"); // converter format
            
            if (strSessionId != null)
                ds = (NCMDataSource) DataSource.newInstance(strSessionId);
            else
                ds = (NCMDataSource) DataSource.newInstance(strUser, strPasswd);
            if (strNodeType.equals("newspaper")) {
                String strLevel = request.getParameter("level");
                String strPubDate = request.getParameter("pubdate");
                if (strLevel == null || strPubDate == null)
                    throw new IllegalArgumentException("Required parameter level or pubdate is missing!");
                Newspaper np = new Newspaper(ds);
                np.write(strLevel, Integer.parseInt(strPubDate), strTextConvert, out);
            } else if (strNodeType.equals("edition")) {
                String strLevel = request.getParameter("level");
                String strName = request.getParameter("name");
                String strPubDate = request.getParameter("pubdate");
                if (strLevel == null || strName == null || strPubDate == null)
                    throw new IllegalArgumentException("Required parameter level, name or pubdate is missing!");
                Edition edt = new Edition(ds);
                edt.write(strLevel, strName, Integer.parseInt(strPubDate), strTextConvert, out);
            } else if (strNodeType.equals("sp") || strNodeType.equals("storypackage")) {
                String strObjId = request.getParameter("id");
                if (strObjId == null)
                    throw new IllegalArgumentException("Required parameter id is missing!");
                String[] sa = strObjId.split(":");
                NCMObjectPK objPK = null;
                if (sa.length > 1)
                    objPK = new NCMObjectPK(Integer.parseInt(sa[0]),
                        Integer.parseInt(sa[1]), NCMObjectPK.LAST_VERSION, 
                        NCMObjectPK.ACTIVE);
                else
                    objPK = new NCMObjectPK(Integer.parseInt(sa[0]));
                StoryPackage sp = new StoryPackage(ds);
                sp.write(objPK, strTextConvert, out);
            } else {
                throw new IllegalArgumentException("Unsupported object type!");            
            }
        } catch (Exception e) {
            log("", e);
            response.sendError(response.SC_CONFLICT, e.toString());
        } finally {            
            out.close();
            if (ds != null) ds.logout();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    public String getServletInfo() {
        return "NCM Export";
    }// </editor-fold>

    private Properties getProperties () throws IOException {
        Properties props = new Properties();

        String strJBossHomeDir = System.getProperty("jboss.server.home.dir");
        String strPropsFile = strJBossHomeDir + File.separator + "conf"
                                + File.separator + "SPHWebExport.properties";
        File propsFile = new File(strPropsFile);
        try {
            props.load(new FileInputStream(propsFile));
        } catch (FileNotFoundException fnf) {
            log("", fnf);
        }

        return props;
    }
}
